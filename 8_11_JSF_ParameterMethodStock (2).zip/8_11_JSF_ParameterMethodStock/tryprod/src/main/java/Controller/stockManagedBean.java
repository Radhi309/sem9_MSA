/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package Controller;

import Client.MSAClient;
import Entity.Stocks;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.inject.Named;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;

/**
 *
 * @author radhika
 */
@Named(value = "stockManagedBean")
@ApplicationScoped
public class stockManagedBean {

    @Inject
    MSAClient msacl;
    Collection<Stocks> stockApps;
    private String searchVal;
    List<String> specArr;
//    private Integer s_id, c_price, sensex_cvalue;
//
//    private String company, category;
//    private Date s_date;
 @PostConstruct
    public void init() {
        specArr = new ArrayList<>();
        specArr.add("banking");
        specArr.add("metal");
        specArr.add("oil");
        specArr.add("infra");
        specArr.add("it");

        searchVal = "banking";
    }
    public Collection<Stocks> getStockApps() {
        return stockApps;
    }

    public void setStockApps(Collection<Stocks> stockApps) {
        this.stockApps = stockApps;
    }

//    public Integer getS_id() {
//        return s_id;
//    }
//
//    public void setS_id(Integer s_id) {
//        this.s_id = s_id;
//    }
//
//    public Integer getC_price() {
//        return c_price;
//    }
//
//    public void setC_price(Integer c_price) {
//        this.c_price = c_price;
//    }
//
//    public Integer getSensex_cvalue() {
//        return sensex_cvalue;
//    }
//
//    public void setSensex_cvalue(Integer sensex_cvalue) {
//        this.sensex_cvalue = sensex_cvalue;
//    }
//
//    public String getCompany() {
//        return company;
//    }
//
//    public void setCompany(String company) {
//        this.company = company;
//    }
//
//    public String getCategory() {
//        return category;
//    }
//
//    public void setCategory(String category) {
//        this.category = category;
//    }
//
//    public Date getS_date() {
//        return s_date;
//    }
//
//    public void setS_date(Date s_date) {
//        this.s_date = s_date;
//    }

    public List<String> getSpecArr() {
        return specArr;
    }

    public void setSpecArr(List<String> specArr) {
        this.specArr = specArr;
    }

    public MSAClient getMsacl() {
        return msacl;
    }

    /**
     * Creates a new instance of stockManagedBean
     */
    public void setMsacl(MSAClient msacl) {
        this.msacl = msacl;
    }

   

    public String getSearchVal() {
        return searchVal;
    }

    public void setSearchVal(String searchVal) {
        this.searchVal = searchVal;
    }

    public stockManagedBean() {
    }

//    public List<Stocks> findAll() {
//        return (List<Stocks>) msacl.stocks();
//
//    }
    public List<Stocks> StockByCat() {
        return (List<Stocks>) msacl.StockByCat(this.searchVal);

    }
}
