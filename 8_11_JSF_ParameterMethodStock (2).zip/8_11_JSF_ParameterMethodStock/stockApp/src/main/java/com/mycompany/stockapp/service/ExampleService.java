package com.mycompany.stockapp.service;

import beans.DataModel;
import java.util.Collection;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import model.Stocks;

@Path("/example")
public class ExampleService {

//    @GET
//    public Response get() {
//        return Response.ok("Hello, world!").build();
//    }
    @Inject
    DataModel dm;

    @Path("/stocks")
//    @RolesAllowed("admin")
//    @RolesAllowed({"admin","user"})
    @GET
//    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Stocks> Stocks() {
        return dm.Stocks();
    }

    @Path("/StockByCat/{category}")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Stocks> StockByCat(@PathParam("category") String category) {
        return dm.StockByCat(category);
    }
}
