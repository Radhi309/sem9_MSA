/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author radhika
 */
@Entity
@Table(name = "stocks")
@NamedQueries({
    @NamedQuery(name = "Stocks.findAll", query = "SELECT s FROM Stocks s"),
    @NamedQuery(name = "Stocks.findBySId", query = "SELECT s FROM Stocks s WHERE s.sId = :sId"),
    @NamedQuery(name = "Stocks.findByCompany", query = "SELECT s FROM Stocks s WHERE s.company = :company"),
    @NamedQuery(name = "Stocks.findBySDate", query = "SELECT s FROM Stocks s WHERE s.sDate = :sDate"),
    @NamedQuery(name = "Stocks.findByCPrice", query = "SELECT s FROM Stocks s WHERE s.cPrice = :cPrice"),
    @NamedQuery(name = "Stocks.findByCategory", query = "SELECT s FROM Stocks s WHERE s.category = :category"),
    @NamedQuery(name = "Stocks.findBySensexCvalue", query = "SELECT s FROM Stocks s WHERE s.sensexCvalue = :sensexCvalue")})
public class Stocks implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "s_id")
    private Integer sId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 40)
    @Column(name = "company")
    private String company;
    @Basic(optional = false)
    @NotNull
    @Column(name = "s_date")
    @Temporal(TemporalType.DATE)
    private Date sDate;
    @Basic(optional = false)
    @NotNull
    @Column(name = "c_price")
    private int cPrice;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "category")
    private String category;
    @Basic(optional = false)
    @NotNull
    @Column(name = "sensex_cvalue")
    private int sensexCvalue;

    public Stocks() {
    }

    public Stocks(Integer sId) {
        this.sId = sId;
    }

    public Stocks(Integer sId, String company, Date sDate, int cPrice, String category, int sensexCvalue) {
        this.sId = sId;
        this.company = company;
        this.sDate = sDate;
        this.cPrice = cPrice;
        this.category = category;
        this.sensexCvalue = sensexCvalue;
    }

    public Integer getSId() {
        return sId;
    }

    public void setSId(Integer sId) {
        this.sId = sId;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public Date getSDate() {
        return sDate;
    }

    public void setSDate(Date sDate) {
        this.sDate = sDate;
    }

    public int getCPrice() {
        return cPrice;
    }

    public void setCPrice(int cPrice) {
        this.cPrice = cPrice;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public int getSensexCvalue() {
        return sensexCvalue;
    }

    public void setSensexCvalue(int sensexCvalue) {
        this.sensexCvalue = sensexCvalue;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (sId != null ? sId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Stocks)) {
            return false;
        }
        Stocks other = (Stocks) object;
        if ((this.sId == null && other.sId != null) || (this.sId != null && !this.sId.equals(other.sId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.Stocks[ sId=" + sId + " ]";
    }
    
}
