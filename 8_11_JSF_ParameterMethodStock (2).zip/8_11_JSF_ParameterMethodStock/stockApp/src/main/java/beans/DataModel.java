/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

import java.util.Collection;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import model.Stocks;

/**
 *
 * @author radhika
 */
//@Named
//@ApplicationScoped
public class DataModel {
@PersistenceContext(unitName = "punit")
     EntityManager em;
    Collection<Stocks> stock;

//    public DataModel() {
//        em = Persistence.createEntityManagerFactory("punit").createEntityManager();
//
//    }

//    public EntityManager getEm() {
//        return em;
//    }
//
//    public void setEm(EntityManager em) {
//        this.em = em;
//    }
//
//    public Collection<Stocks> getStock() {
//        return stock;
//    }
//
//    public void setStock(Collection<Stocks> stock) {
//        this.stock = stock;
//    }

    public Collection<Stocks> Stocks() {
        return em.createNamedQuery("Stocks.findAll").getResultList();
    }

    public Collection<Stocks> StockByCat(String category) {
        stock = (Collection<Stocks>) em.createNamedQuery("Stocks.findByCategory").setParameter("category", category).getResultList();
        return stock;
    }

}
