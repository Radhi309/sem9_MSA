package com.mycompany.trycons.service;

import Entity.Students;
import Model.DataModel;
import java.util.Collection;
import javax.annotation.security.RolesAllowed;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/example")
public class ExampleService {

      @Inject DataModel dm;
    @Path("/students")
    @RolesAllowed("admin")
//    @RolesAllowed({"admin","user"})
    @GET
//   @Produces(MediaType.APPLICATION_JSON)
    public Collection<Students> students() {
        return dm.students();
    }

    @GET
    public Response get() {
        return Response.ok("Hello, world!").build();
    }

}
