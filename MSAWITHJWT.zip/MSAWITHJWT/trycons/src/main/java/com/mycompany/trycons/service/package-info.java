
/**
 * Restful services here
 */
package com.mycompany.trycons.service;