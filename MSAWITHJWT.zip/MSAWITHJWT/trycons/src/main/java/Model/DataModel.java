/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import Entity.Students;
import java.util.Collection;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author radhika
 */
public class DataModel {
    @PersistenceContext(unitName = "punit")
     EntityManager em;
    public Collection<Students> students()
     {
         return em.createNamedQuery("Students.findAll").getResultList();
     }
    
}
