
/**
 * Restful services here
 */
package com.mycompany.docfrontapp.service;