
/**
 * Restful services here
 */
package com.mycompany.tryprod.service;