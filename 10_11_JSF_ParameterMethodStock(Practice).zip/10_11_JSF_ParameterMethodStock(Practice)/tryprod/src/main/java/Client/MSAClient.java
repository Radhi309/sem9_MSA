/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Client;

import Entity.Stocks;
import java.util.Collection;
import javax.annotation.security.RolesAllowed;
import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.eclipse.microprofile.config.Config;
import org.eclipse.microprofile.config.ConfigProvider;
import org.eclipse.microprofile.rest.client.annotation.ClientHeaderParam;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

/**
 *
 * @author radhika
 */
@RegisterRestClient(configKey = "myclient")
@ApplicationScoped
//@Path("/StockByCat/{category}")
@Path("/example")
public interface MSAClient {
        @ClientHeaderParam(name="authorization",value="{generateJWTToken}")


    @GET
    @Path("/stocks")
//    @RolesAllowed("admin")
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Stocks> stocks();

    @GET
    @Path("/StockByCat/{category}")
    @RolesAllowed({"admin","user"})
//    @ClientHeaderParam(name="authorization", value="{generateJWTToken}")
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Stocks> StockByCat(@PathParam("category") String category);

default String generateJWTToken()
    {
        Config config = ConfigProvider.getConfig();
        String jwt = config.getValue("jwt-string", String.class);
        String authtoken = "Bearer "+jwt;
        return authtoken;
    }
}
