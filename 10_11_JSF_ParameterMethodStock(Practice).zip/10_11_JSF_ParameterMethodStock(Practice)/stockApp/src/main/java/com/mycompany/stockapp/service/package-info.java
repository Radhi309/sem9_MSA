
/**
 * Restful services here
 */
package com.mycompany.stockapp.service;